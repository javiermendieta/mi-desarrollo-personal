// ==================== CALENDAR ====================
export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  startDate: string;
  endDate: string;
  color: string;
  category: string;
  isRecurring: boolean;
  recurrencePattern?: 'daily' | 'weekly' | 'monthly' | 'yearly';
  recurrenceEnd?: string;
}

// ==================== SPORTS ====================
export interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: number;
  weight?: number;
  notes?: string;
  completed: boolean;
}

export interface WorkoutRoutine {
  id: string;
  name: string;
  exercises: Exercise[];
  createdAt: string;
}

export interface WorkoutSession {
  id: string;
  routineId: string;
  sportId: string;
  date: string;
  exercises: Exercise[];
  duration: number;
  notes?: string;
}

export interface Sport {
  id: string;
  name: string;
  icon: string;
  color: string;
  isActive: boolean;
  routines: WorkoutRoutine[];
  sessions: WorkoutSession[];
}

// ==================== YOGA & MEDITATION ====================
export interface YogaExercise {
  id: string;
  name: string;
  description: string;
  duration: number; // in minutes
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  category: string;
  image?: string;
}

export interface MeditationSession {
  id: string;
  date: string;
  duration: number;
  type: 'mindfulness' | 'breathing' | 'guided' | 'body-scan';
  notes?: string;
  completed: boolean;
}

export interface YogaSession {
  id: string;
  date: string;
  exercises: string[]; // yoga exercise ids
  duration: number;
  completed: boolean;
}

// ==================== READING ====================
export interface BookNote {
  id: string;
  page: number;
  content: string;
  createdAt: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  totalPages: number;
  currentPage: number;
  startDate: string;
  finishDate?: string;
  notes: BookNote[];
  status: 'reading' | 'completed' | 'paused';
}

// ==================== DIARY ====================
export type Mood = 'great' | 'good' | 'neutral' | 'bad' | 'terrible';

export interface DiaryEntry {
  id: string;
  date: string;
  title?: string;
  content: string;
  mood: Mood;
  tags: string[];
  gratitude?: string[];
  createdAt: string;
}

export interface LimitingBelief {
  id: string;
  belief: string;
  explanation: string;
  dailyWork: string;
  createdAt: string;
  progress: number; // 0-100
  isOvercome: boolean;
  reflections: { date: string; note: string }[];
}

// ==================== GOALS ====================
export type GoalTimeframe = 'short' | 'medium' | 'long';
export type GoalCategory = 'health' | 'career' | 'finance' | 'relationships' | 'personal' | 'education' | 'other';

export interface Goal {
  id: string;
  title: string;
  description?: string;
  timeframe: GoalTimeframe;
  category: GoalCategory;
  deadline?: string;
  progress: number;
  milestones: { id: string; title: string; completed: boolean }[];
  createdAt: string;
  isCompleted: boolean;
}

// ==================== HABITS ====================
export interface HabitLog {
  date: string;
  completed: boolean;
}

export interface Habit {
  id: string;
  name: string;
  description?: string;
  icon: string;
  color: string;
  frequency: 'daily' | 'weekdays' | 'weekends' | 'custom';
  customDays?: number[]; // 0-6 for Sunday-Saturday
  logs: HabitLog[];
  createdAt: string;
  isActive: boolean;
}

// ==================== FINANCES ====================
export type TransactionType = 'income' | 'expense';
export type TransactionCategory = 'salary' | 'freelance' | 'investment' | 'food' | 'transport' | 'entertainment' | 'health' | 'education' | 'shopping' | 'bills' | 'other';

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: TransactionCategory;
  description: string;
  date: string;
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline?: string;
  createdAt: string;
}

export interface Budget {
  id: string;
  category: TransactionCategory;
  limit: number;
  month: string; // YYYY-MM format
}

// ==================== HEALTH ====================
export interface SleepLog {
  id: string;
  date: string;
  sleepTime: string;
  wakeTime: string;
  quality: 1 | 2 | 3 | 4 | 5;
  notes?: string;
}

export interface HydrationLog {
  id: string;
  date: string;
  glasses: number;
  target: number;
}

export interface HealthEntry {
  id: string;
  date: string;
  weight?: number;
  steps?: number;
  calories?: number;
  notes?: string;
}

// ==================== NOTES ====================
export interface QuickNote {
  id: string;
  title: string;
  content: string;
  category: string;
  color: string;
  isPinned: boolean;
  createdAt: string;
  updatedAt: string;
}

// ==================== AI AGENT ====================
export interface AIProfile {
  personality: string;
  lifeGoals: string;
  currentChallenges: string;
  values: string;
  interests: string;
  additionalInfo?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface AIConversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: string;
  updatedAt: string;
}

// ==================== APP STATE ====================
export interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  language: string;
  notifications: boolean;
  weekStartsOn: 0 | 1 | 2 | 3 | 4 | 5 | 6;
}

export interface AppData {
  settings: AppSettings;
  aiProfile: AIProfile;
  events: CalendarEvent[];
  sports: Sport[];
  yogaExercises: YogaExercise[];
  meditationSessions: MeditationSession[];
  yogaSessions: YogaSession[];
  books: Book[];
  diaryEntries: DiaryEntry[];
  limitingBeliefs: LimitingBelief[];
  goals: Goal[];
  habits: Habit[];
  transactions: Transaction[];
  savingsGoals: SavingsGoal[];
  budgets: Budget[];
  sleepLogs: SleepLog[];
  hydrationLogs: HydrationLog[];
  healthEntries: HealthEntry[];
  quickNotes: QuickNote[];
  conversations: AIConversation[];
}
