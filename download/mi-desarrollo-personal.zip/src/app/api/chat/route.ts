import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { messages, profile } = body;

    const zai = await ZAI.create();

    // Build system prompt with user profile
    const systemPrompt = `Eres un asistente personal de desarrollo personal. Tu objetivo es ayudar al usuario en su crecimiento personal, espiritual y profesional.

INFORMACIÓN DEL PERFIL DEL USUARIO:
${profile?.personality ? `Personalidad: ${profile.personality}` : ''}
${profile?.lifeGoals ? `Objetivos de vida: ${profile.lifeGoals}` : ''}
${profile?.currentChallenges ? `Desafíos actuales: ${profile.currentChallenges}` : ''}
${profile?.values ? `Valores: ${profile.values}` : ''}
${profile?.interests ? `Intereses: ${profile.interests}` : ''}
${profile?.additionalInfo ? `Información adicional: ${profile.additionalInfo}` : ''}

INSTRUCCIONES:
- Sé cálido, empático y comprensivo
- Adapta tus respuestas al perfil del usuario
- Cuando te pidan una cita bíblica, busca un versículo apropiado para la situación
- Ofrece consejos prácticos y accionables
- Ayuda con metas, hábitos, motivación y bienestar
- Recuerda las conversaciones anteriores y haz referencia a ellas cuando sea relevante
- Si el usuario menciona problemas o dificultades, ofrece apoyo y orientación
- Usa un tono cercano pero profesional
- Responde en el mismo idioma que el usuario (español)

Para citas bíblicas, usa versiones en español como Reina Valera o Nueva Versión Internacional.`;

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        ...messages,
      ],
      temperature: 0.7,
      max_tokens: 1000,
    });

    const responseMessage = completion.choices[0]?.message?.content || 'Lo siento, no pude procesar tu mensaje.';

    return NextResponse.json({ message: responseMessage });
  } catch (error) {
    console.error('AI Chat Error:', error);
    return NextResponse.json(
      { error: 'Error al procesar la solicitud' },
      { status: 500 }
    );
  }
}
