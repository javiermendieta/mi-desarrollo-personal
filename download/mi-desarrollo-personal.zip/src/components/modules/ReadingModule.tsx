'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  BookOpen,
  Plus,
  Trash2,
  Edit,
  Search,
  BookMarked,
  FileText,
  ChevronRight,
  Check,
} from 'lucide-react';
import { useAppStore } from '@/lib/store';
import type { Book, BookNote } from '@/types';
import { v4 as uuidv4 } from 'uuid';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export function ReadingModule() {
  const {
    books,
    addBook,
    updateBook,
    deleteBook,
    addBookNote,
    updateBookNote,
    deleteBookNote,
  } = useAppStore();

  const [isBookDialogOpen, setIsBookDialogOpen] = useState(false);
  const [isNoteDialogOpen, setIsNoteDialogOpen] = useState(false);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [editingNote, setEditingNote] = useState<BookNote | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'reading' | 'completed' | 'paused'>('all');

  // Book form
  const [bookTitle, setBookTitle] = useState('');
  const [bookAuthor, setBookAuthor] = useState('');
  const [bookTotalPages, setBookTotalPages] = useState('');
  const [bookCurrentPage, setBookCurrentPage] = useState('');
  const [bookStatus, setBookStatus] = useState<'reading' | 'completed' | 'paused'>('reading');

  // Note form
  const [notePage, setNotePage] = useState('');
  const [noteContent, setNoteContent] = useState('');

  const openBookDialog = (book?: Book) => {
    if (book) {
      setEditingBook(book);
      setBookTitle(book.title);
      setBookAuthor(book.author);
      setBookTotalPages(book.totalPages.toString());
      setBookCurrentPage(book.currentPage.toString());
      setBookStatus(book.status);
    } else {
      setEditingBook(null);
      setBookTitle('');
      setBookAuthor('');
      setBookTotalPages('');
      setBookCurrentPage('0');
      setBookStatus('reading');
    }
    setIsBookDialogOpen(true);
  };

  const handleSaveBook = () => {
    if (!bookTitle.trim() || !bookTotalPages) return;

    const book: Partial<Book> = {
      title: bookTitle,
      author: bookAuthor,
      totalPages: parseInt(bookTotalPages) || 0,
      currentPage: parseInt(bookCurrentPage) || 0,
      status: bookStatus,
      startDate: editingBook?.startDate || new Date().toISOString(),
      notes: editingBook?.notes || [],
    };

    if (parseInt(bookCurrentPage || '0') >= parseInt(bookTotalPages || '0')) {
      book.status = 'completed';
      book.finishDate = new Date().toISOString();
    }

    if (editingBook) {
      updateBook(editingBook.id, book);
    } else {
      addBook({
        id: uuidv4(),
        ...book,
        notes: [],
      } as Book);
    }

    setIsBookDialogOpen(false);
    resetBookForm();
  };

  const resetBookForm = () => {
    setBookTitle('');
    setBookAuthor('');
    setBookTotalPages('');
    setBookCurrentPage('0');
    setBookStatus('reading');
    setEditingBook(null);
  };

  const openNoteDialog = (book: Book, note?: BookNote) => {
    setSelectedBook(book);
    if (note) {
      setEditingNote(note);
      setNotePage(note.page.toString());
      setNoteContent(note.content);
    } else {
      setEditingNote(null);
      setNotePage(book.currentPage.toString());
      setNoteContent('');
    }
    setIsNoteDialogOpen(true);
  };

  const handleSaveNote = () => {
    if (!noteContent.trim() || !selectedBook) return;

    const note: BookNote = {
      id: editingNote?.id || uuidv4(),
      page: parseInt(notePage) || 0,
      content: noteContent,
      createdAt: editingNote?.createdAt || new Date().toISOString(),
    };

    if (editingNote) {
      updateBookNote(selectedBook.id, editingNote.id, note);
    } else {
      addBookNote(selectedBook.id, note);
    }

    setIsNoteDialogOpen(false);
    resetNoteForm();
  };

  const resetNoteForm = () => {
    setNotePage('');
    setNoteContent('');
    setEditingNote(null);
  };

  const openBookDetail = (book: Book) => {
    setSelectedBook(book);
    setIsDetailOpen(true);
  };

  const updateCurrentPage = (bookId: string, newPage: number) => {
    const book = books.find((b) => b.id === bookId);
    if (!book) return;

    const updates: Partial<Book> = {
      currentPage: Math.min(newPage, book.totalPages),
    };

    if (newPage >= book.totalPages) {
      updates.status = 'completed';
      updates.finishDate = new Date().toISOString();
    }

    updateBook(bookId, updates);
  };

  const filteredBooks = books
    .filter((book) => {
      if (filterStatus !== 'all' && book.status !== filterStatus) return false;
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          book.title.toLowerCase().includes(query) ||
          book.author.toLowerCase().includes(query) ||
          book.notes.some((n) => n.content.toLowerCase().includes(query))
        );
      }
      return true;
    })
    .sort((a, b) => {
      if (a.status === 'reading' && b.status !== 'reading') return -1;
      if (a.status !== 'reading' && b.status === 'reading') return 1;
      return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
    });

  const readingBooks = books.filter((b) => b.status === 'reading');
  const completedBooks = books.filter((b) => b.status === 'completed');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'reading':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100';
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100';
      case 'paused':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100';
      default:
        return '';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'reading':
        return 'Leyendo';
      case 'completed':
        return 'Completado';
      case 'paused':
        return 'Pausado';
      default:
        return status;
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <CardTitle className="text-xl flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Biblioteca
            </CardTitle>
            <Button onClick={() => openBookDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Añadir Libro
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="text-center p-3 rounded-lg bg-muted/50">
              <p className="text-2xl font-bold">{readingBooks.length}</p>
              <p className="text-xs text-muted-foreground">Leyendo</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/50">
              <p className="text-2xl font-bold">{completedBooks.length}</p>
              <p className="text-xs text-muted-foreground">Completados</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/50">
              <p className="text-2xl font-bold">{books.length}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </div>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar libros o notas..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={filterStatus} onValueChange={(v) => setFilterStatus(v as typeof filterStatus)}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="reading">Leyendo</SelectItem>
                <SelectItem value="completed">Completados</SelectItem>
                <SelectItem value="paused">Pausados</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Books List */}
      {filteredBooks.length > 0 ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredBooks.map((book) => {
            const progress = Math.round((book.currentPage / book.totalPages) * 100);
            return (
              <Card key={book.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-base truncate">{book.title}</CardTitle>
                      <p className="text-sm text-muted-foreground">{book.author}</p>
                    </div>
                    <Badge className={getStatusColor(book.status)}>
                      {getStatusLabel(book.status)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Página {book.currentPage} de {book.totalPages}</span>
                        <span>{progress}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>

                    {book.status === 'reading' && (
                      <div className="flex gap-2">
                        <Input
                          type="number"
                          value={book.currentPage}
                          onChange={(e) => updateCurrentPage(book.id, parseInt(e.target.value) || 0)}
                          className="w-20"
                          min={0}
                          max={book.totalPages}
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateCurrentPage(book.id, book.currentPage + 10)}
                        >
                          +10
                        </Button>
                      </div>
                    )}

                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">
                        {book.notes.length} notas
                      </span>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => openNoteDialog(book)}>
                          <FileText className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => openBookDetail(book)}>
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => openBookDialog(book)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="sm" className="text-destructive">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>¿Eliminar libro?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Se eliminarán también todas las notas asociadas.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deleteBook(book.id)}>
                                Eliminar
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <BookMarked className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Tu biblioteca está vacía</h3>
            <p className="text-muted-foreground mb-6">
              Añade libros para hacer seguimiento de tu lectura
            </p>
            <Button onClick={() => openBookDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Añadir primer libro
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Book Dialog */}
      <Dialog open={isBookDialogOpen} onOpenChange={setIsBookDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingBook ? 'Editar Libro' : 'Nuevo Libro'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Título *</Label>
              <Input
                value={bookTitle}
                onChange={(e) => setBookTitle(e.target.value)}
                placeholder="Nombre del libro"
              />
            </div>
            <div>
              <Label>Autor</Label>
              <Input
                value={bookAuthor}
                onChange={(e) => setBookAuthor(e.target.value)}
                placeholder="Nombre del autor"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Total de páginas *</Label>
                <Input
                  type="number"
                  value={bookTotalPages}
                  onChange={(e) => setBookTotalPages(e.target.value)}
                  min={1}
                />
              </div>
              <div>
                <Label>Página actual</Label>
                <Input
                  type="number"
                  value={bookCurrentPage}
                  onChange={(e) => setBookCurrentPage(e.target.value)}
                  min={0}
                />
              </div>
            </div>
            <div>
              <Label>Estado</Label>
              <Select
                value={bookStatus}
                onValueChange={(v) => setBookStatus(v as 'reading' | 'completed' | 'paused')}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="reading">Leyendo</SelectItem>
                  <SelectItem value="completed">Completado</SelectItem>
                  <SelectItem value="paused">Pausado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsBookDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveBook} disabled={!bookTitle.trim() || !bookTotalPages}>
              Guardar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Note Dialog */}
      <Dialog open={isNoteDialogOpen} onOpenChange={setIsNoteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingNote ? 'Editar Nota' : 'Nueva Nota'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Página</Label>
              <Input
                type="number"
                value={notePage}
                onChange={(e) => setNotePage(e.target.value)}
                min={1}
                max={selectedBook?.totalPages}
              />
            </div>
            <div>
              <Label>Nota *</Label>
              <Textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                placeholder="Escribe tu nota o cita..."
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsNoteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveNote} disabled={!noteContent.trim()}>
              Guardar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Book Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{selectedBook?.title}</DialogTitle>
          </DialogHeader>
          {selectedBook && (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Badge className={getStatusColor(selectedBook.status)}>
                  {getStatusLabel(selectedBook.status)}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  por {selectedBook.author}
                </span>
              </div>

              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Progreso</span>
                  <span>
                    {selectedBook.currentPage} / {selectedBook.totalPages} páginas
                  </span>
                </div>
                <Progress
                  value={(selectedBook.currentPage / selectedBook.totalPages) * 100}
                  className="h-2"
                />
              </div>

              <div className="text-sm text-muted-foreground">
                <p>Iniciado: {format(new Date(selectedBook.startDate), 'd MMM yyyy', { locale: es })}</p>
                {selectedBook.finishDate && (
                  <p>Completado: {format(new Date(selectedBook.finishDate), 'd MMM yyyy', { locale: es })}</p>
                )}
              </div>

              {/* Notes */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">Notas</h4>
                  <Button variant="ghost" size="sm" onClick={() => openNoteDialog(selectedBook)}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                {selectedBook.notes.length > 0 ? (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {selectedBook.notes
                      .sort((a, b) => a.page - b.page)
                      .map((note) => (
                        <div
                          key={note.id}
                          className="p-3 rounded-lg bg-muted/50"
                        >
                          <div className="flex items-center justify-between mb-1">
                            <Badge variant="outline">Pág. {note.page}</Badge>
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 w-6"
                                onClick={() => openNoteDialog(selectedBook, note)}
                              >
                                <Edit className="h-3 w-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 w-6 text-destructive"
                                onClick={() => deleteBookNote(selectedBook.id, note.id)}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                          <p className="text-sm">{note.content}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {format(new Date(note.createdAt), 'd MMM yyyy', { locale: es })}
                          </p>
                        </div>
                      ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Sin notas aún
                  </p>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
