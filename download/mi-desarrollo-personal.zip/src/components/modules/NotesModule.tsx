'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  StickyNote,
  Plus,
  Trash2,
  Edit,
  Pin,
  PinOff,
  Search,
} from 'lucide-react';
import { useAppStore } from '@/lib/store';
import { NOTE_CATEGORIES, NOTE_COLORS } from '@/lib/constants';
import type { QuickNote } from '@/types';
import { v4 as uuidv4 } from 'uuid';
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';

export function NotesModule() {
  const { quickNotes, addQuickNote, updateQuickNote, deleteQuickNote } = useAppStore();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<QuickNote | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');

  // Form state
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [noteCategory, setNoteCategory] = useState(NOTE_CATEGORIES[0]);
  const [noteColor, setNoteColor] = useState(NOTE_COLORS[0].value);

  const openDialog = (note?: QuickNote) => {
    if (note) {
      setEditingNote(note);
      setNoteTitle(note.title);
      setNoteContent(note.content);
      setNoteCategory(note.category);
      setNoteColor(note.color);
    } else {
      setEditingNote(null);
      setNoteTitle('');
      setNoteContent('');
      setNoteCategory(NOTE_CATEGORIES[0]);
      setNoteColor(NOTE_COLORS[0].value);
    }
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (!noteTitle.trim() && !noteContent.trim()) return;

    const note: Partial<QuickNote> = {
      title: noteTitle || 'Sin título',
      content: noteContent,
      category: noteCategory,
      color: noteColor,
      updatedAt: new Date().toISOString(),
    };

    if (editingNote) {
      updateQuickNote(editingNote.id, note);
    } else {
      addQuickNote({
        id: uuidv4(),
        createdAt: new Date().toISOString(),
        isPinned: false,
        ...note,
      } as QuickNote);
    }

    setIsDialogOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setNoteTitle('');
    setNoteContent('');
    setNoteCategory(NOTE_CATEGORIES[0]);
    setNoteColor(NOTE_COLORS[0].value);
    setEditingNote(null);
  };

  const togglePin = (id: string, isPinned: boolean) => {
    updateQuickNote(id, { isPinned: !isPinned });
  };

  const filteredNotes = quickNotes
    .filter((note) => {
      if (filterCategory !== 'all' && note.category !== filterCategory) return false;
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          note.title.toLowerCase().includes(query) ||
          note.content.toLowerCase().includes(query)
        );
      }
      return true;
    })
    .sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    });

  const pinnedNotes = filteredNotes.filter((n) => n.isPinned);
  const unpinnedNotes = filteredNotes.filter((n) => !n.isPinned);

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <CardTitle className="text-xl flex items-center gap-2">
              <StickyNote className="h-5 w-5" />
              Notas Rápidas
            </CardTitle>
            <Button onClick={() => openDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Nueva Nota
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar notas..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                {NOTE_CATEGORIES.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Pinned Notes */}
      {pinnedNotes.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-medium text-muted-foreground flex items-center gap-2">
            <Pin className="h-4 w-4" />
            Fijadas
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {pinnedNotes.map((note) => (
              <Card
                key={note.id}
                className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                style={{ backgroundColor: note.color }}
                onClick={() => openDialog(note)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-medium line-clamp-1">{note.title}</h3>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 -mr-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        togglePin(note.id, note.isPinned);
                      }}
                    >
                      <PinOff className="h-3 w-3" />
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-3 mb-2">
                    {note.content}
                  </p>
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary" className="text-xs">
                      {note.category}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {format(parseISO(note.updatedAt), 'd MMM', { locale: es })}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* All Notes */}
      {unpinnedNotes.length > 0 ? (
        <div className="space-y-3">
          {pinnedNotes.length > 0 && (
            <h3 className="font-medium text-muted-foreground">Otras notas</h3>
          )}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {unpinnedNotes.map((note) => (
              <Card
                key={note.id}
                className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                style={{ backgroundColor: note.color }}
                onClick={() => openDialog(note)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-medium line-clamp-1">{note.title}</h3>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 -mr-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        togglePin(note.id, note.isPinned);
                      }}
                    >
                      <Pin className="h-3 w-3" />
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-3 mb-2">
                    {note.content}
                  </p>
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary" className="text-xs">
                      {note.category}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {format(parseISO(note.updatedAt), 'd MMM', { locale: es })}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ) : pinnedNotes.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <StickyNote className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Sin notas</h3>
            <p className="text-muted-foreground mb-6">
              Captura ideas, pensamientos y recordatorios
            </p>
            <Button onClick={() => openDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Crear primera nota
            </Button>
          </CardContent>
        </Card>
      ) : null}

      {/* Note Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingNote ? 'Editar Nota' : 'Nueva Nota'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Título</Label>
              <Input
                value={noteTitle}
                onChange={(e) => setNoteTitle(e.target.value)}
                placeholder="Título de la nota..."
              />
            </div>
            <div>
              <Label>Contenido</Label>
              <Textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                placeholder="Escribe tu nota..."
                rows={5}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Categoría</Label>
                <Select value={noteCategory} onValueChange={setNoteCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {NOTE_CATEGORIES.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Color</Label>
                <div className="flex gap-1 mt-1">
                  {NOTE_COLORS.map((c) => (
                    <button
                      key={c.value}
                      type="button"
                      className={`w-6 h-6 rounded border-2 ${
                        noteColor === c.value ? 'border-foreground' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: c.value }}
                      onClick={() => setNoteColor(c.value)}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            {editingNote && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive">
                    <Trash2 className="h-4 w-4 mr-2" />
                    Eliminar
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>¿Eliminar nota?</AlertDialogTitle>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => {
                        deleteQuickNote(editingNote.id);
                        setIsDialogOpen(false);
                      }}
                    >
                      Eliminar
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSave}>
              Guardar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
